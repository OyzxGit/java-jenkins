package com.mypro.model.interfaces;
/**
 * �����¼�
 * @author Leslie Leung
 *
 */
public interface OnClickListener {
	public void onClick();
}
